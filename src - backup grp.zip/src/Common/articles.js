import placeholderImg from "./Images/placeholder.jpg";

const article = [
    {
        id: 1,
        pic: placeholderImg,
        section: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente est dolore, nemo tempore dicta mollitia eum consequuntur fugiat harum, optio placeat officiis dolorum consequatur provident quae expedita odit corrupti ipsam, exercitationem assumenda minima. Sint, assumenda delectus eaque sit iusto dolorum nemo enim aut, dolor doloribus debitis? Beatae eos eum blanditiis.Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente est dolore, nemo tempore dicta mollitia eum consequuntur fugiat harum, optio placeat officiis dolorum consequatur provident quae expedita odit corrupti ipsam, exercitationem assumenda minima. Sint, assumenda delectus eaque sit iusto dolorum nemo enim aut, dolor doloribus debitis? Beatae eos eum blanditiis."
    },
    {
        id: 2,
        pic: placeholderImg,
        section: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente est dolore, nemo tempore dicta mollitia eum consequuntur fugiat harum, optio placeat officiis dolorum consequatur provident quae expedita odit corrupti ipsam, exercitationem assumenda minima. Sint, assumenda delectus eaque sit iusto dolorum nemo enim aut, dolor doloribus debitis? Beatae eos eum blanditiis.Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente est dolore, nemo tempore dicta mollitia eum consequuntur fugiat harum, optio placeat officiis dolorum consequatur provident quae expedita odit corrupti ipsam, exercitationem assumenda minima. Sint, assumenda delectus eaque sit iusto dolorum nemo enim aut, dolor doloribus debitis? Beatae eos eum blanditiis."
    },
    {
        id: 3,
        pic: placeholderImg,
        section: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente est dolore, nemo tempore dicta mollitia eum consequuntur fugiat harum, optio placeat officiis dolorum consequatur provident quae expedita odit corrupti ipsam, exercitationem assumenda minima. Sint, assumenda delectus eaque sit iusto dolorum nemo enim aut, dolor doloribus debitis? Beatae eos eum blanditiis.Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente est dolore, nemo tempore dicta mollitia eum consequuntur fugiat harum, optio placeat officiis dolorum consequatur provident quae expedita odit corrupti ipsam, exercitationem assumenda minima. Sint, assumenda delectus eaque sit iusto dolorum nemo enim aut, dolor doloribus debitis? Beatae eos eum blanditiis."
    },
    {
        id: 4,
        pic: placeholderImg,
        section: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente est dolore, nemo tempore dicta mollitia eum consequuntur fugiat harum, optio placeat officiis dolorum consequatur provident quae expedita odit corrupti ipsam, exercitationem assumenda minima. Sint, assumenda delectus eaque sit iusto dolorum nemo enim aut, dolor doloribus debitis? Beatae eos eum blanditiis.Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente est dolore, nemo tempore dicta mollitia eum consequuntur fugiat harum, optio placeat officiis dolorum consequatur provident quae expedita odit corrupti ipsam, exercitationem assumenda minima. Sint, assumenda delectus eaque sit iusto dolorum nemo enim aut, dolor doloribus debitis? Beatae eos eum blanditiis."
    },
]

export default article