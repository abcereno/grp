import grp from "./Images/grp.png";

const images = [
    {
        id: 1,
        src: grp,
        alt: "GRP Credit Services"
    },
    {
        id: 2,
        src: grp,
        alt: "GRP Credit Services"
    },
    {
        id: 3,
        src: grp,
        alt: "GRP Credit Services"
    },
    {
        id: 4,
        src: grp,
        alt: "GRP Credit Services"
    },
]

export default images;